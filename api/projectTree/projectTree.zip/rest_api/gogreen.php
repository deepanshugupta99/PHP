<?php
include('./classes/controller/Controller.php');
$controller=new Controller;
$user=new Users;
if(isset($_POST['registerUser'])){
    $user->setName($_POST['name']);
    $user->setEmail($_POST['email']);
    echo $uesr;

}
elseif(isset($_GET['login'])){
    $user->setName($_GET['name']);
    $user->setEmail($_GET['email']);
    echo $user;
}


?>